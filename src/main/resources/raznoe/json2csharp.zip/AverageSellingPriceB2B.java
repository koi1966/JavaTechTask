public class AverageSellingPriceB2B{
    public double amount;
    public String currencyCode;
}
