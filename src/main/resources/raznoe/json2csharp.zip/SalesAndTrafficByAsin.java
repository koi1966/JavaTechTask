public class SalesAndTrafficByAsin{
    public String parentAsin;
    public SalesByAsin salesByAsin;
    public TrafficByAsin trafficByAsin;
}
