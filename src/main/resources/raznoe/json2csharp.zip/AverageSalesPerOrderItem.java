public class AverageSalesPerOrderItem{
    public double amount;
    public String currencyCode;
}
