public class ClaimsAmount{
    public int amount;
    public String currencyCode;
}
