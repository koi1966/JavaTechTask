public class AverageSalesPerOrderItemB2B{
    public double amount;
    public String currencyCode;
}
