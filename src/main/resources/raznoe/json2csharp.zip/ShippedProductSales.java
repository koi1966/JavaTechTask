public class ShippedProductSales{
    public double amount;
    public String currencyCode;
}
