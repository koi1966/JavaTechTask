public class OrderedProductSalesB2B{
    public double amount;
    public String currencyCode;
}
