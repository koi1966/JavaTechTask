public class ReportOptions{
    public String dateGranularity;
    public String asinGranularity;
}
