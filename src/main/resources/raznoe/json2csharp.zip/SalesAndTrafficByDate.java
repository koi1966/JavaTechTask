public class SalesAndTrafficByDate{
    public String date;
    public SalesByDate salesByDate;
    public TrafficByDate trafficByDate;
}
