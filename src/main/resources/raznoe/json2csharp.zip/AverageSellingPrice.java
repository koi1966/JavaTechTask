public class AverageSellingPrice{
    public double amount;
    public String currencyCode;
}
