public class Root{
    public ReportSpecification reportSpecification;
    public ArrayList<SalesAndTrafficByDate> salesAndTrafficByDate;
    public ArrayList<SalesAndTrafficByAsin> salesAndTrafficByAsin;
}
