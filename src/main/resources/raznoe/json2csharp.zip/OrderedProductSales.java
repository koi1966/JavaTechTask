public class OrderedProductSales{
    public double amount;
    public String currencyCode;
}
