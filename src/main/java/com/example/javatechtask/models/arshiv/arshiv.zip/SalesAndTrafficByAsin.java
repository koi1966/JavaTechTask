package com.example.javatechtask.models.arshiv;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

//@Setter
//@Getter
//@Document
public class SalesAndTrafficByAsin {
//    @Id
//    private UUID id;
    private String parentAsin;
    private SalesByAsin salesByAsin;
    private TrafficByAsin trafficByAsin;
}
