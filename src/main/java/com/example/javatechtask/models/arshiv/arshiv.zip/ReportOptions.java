package com.example.javatechtask.models.arshiv;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;


public class ReportOptions {

    private String dateGranularity;
    private String asinGranularity;

}
