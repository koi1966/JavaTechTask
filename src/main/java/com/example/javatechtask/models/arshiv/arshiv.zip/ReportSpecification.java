package com.example.javatechtask.models.arshiv;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

//@Setter
//@Getter
//@Document
//@JsonIgnoreProperties(ignoreUnknown = true)
public class ReportSpecification {
//    @Id
//    private UUID id;
private List<ReportSpecification> reportSpecifications;
    private String reportType;
    private ReportOptions reportOptions;
    private String dataStartTime;
    private String dataEndTime;
    private List<String> marketplaceIds;

}
