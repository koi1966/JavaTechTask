package com.example.javatechtask.models.arshiv;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;


public class AverageSellingPriceB2B {
    private double amount;
    private String currencyCode;
}
