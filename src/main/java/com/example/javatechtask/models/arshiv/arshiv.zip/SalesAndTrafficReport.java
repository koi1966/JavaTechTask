package com.example.javatechtask.models.arshiv;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

//@Setter
//@Getter
//@Document
//@Document(collection = "salesAndTrafficReports")
public class SalesAndTrafficReport {

//    @Id
//    private UUID id;

    private ReportSpecification reportSpecification;
    private List<SalesAndTrafficByDate> salesAndTrafficByDate;
    private List<SalesAndTrafficByAsin> salesAndTrafficByAsin;

}

