package com.example.javatechtask.models.arshiv;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;


public class OrderedProductSalesB2B {
    public Double amount;
    public String currencyCode;

}
